FLEUR DE LUNE MANAGEMENT — WEBSITE STARTER

CONTENTS
- Six responsive pages: Home, About, Our Vision, Talent, Creative, Contact
- Shared styles and a small mobile navigation script
- No paid software or build tools required

BEFORE PUBLISHING
1. Open contact.html and replace YOUR-AGENCY-EMAIL@example.com with an agency email you control.
2. Review every page and adjust any wording that does not accurately describe your business.
3. Replace the sample editorial photography with images you have permission to use. Current images are loaded from Unsplash URLs and require internet access.
4. Do not claim to represent models, have clients, offer castings or have industry partnerships unless that is true.
5. Add your social links only when you have confirmed the correct public account URLs.

FREE PUBLISHING OPTION: GITHUB PAGES
1. Create a free account at https://github.com/
2. Create a new public repository, for example fleur-de-lune-website.
3. Upload all files in this folder (not the folder itself) to the repository's root.
4. In the repository, open Settings → Pages.
5. Under Build and deployment, choose Deploy from a branch, select main and /(root), then Save.
6. Wait for the published address shown in Settings → Pages.

Alternative: Netlify offers a free tier and lets you deploy a folder by dragging it into its deploy area. Check current plan limits before publishing.

IMPORTANT
This is a static introductory website. It does not include a working model application form, booking system, member database or legal representation documents. The talent page intentionally says the roster is in development. Add secure, professionally reviewed processes before collecting applications or personal information.
